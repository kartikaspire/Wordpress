<?php
echo '<ul>';
foreach ($stateList as $value) {
	if ($value['status'] == 1) {
		$status = "Enabled";
	} else {
		$status = "Disabled";
	}
	echo '<li>'.$value['state'].'(Status -'.$status.', State Code - '.$value['state_code'].')'.'</li>';
}
echo '</ul>';
?>
