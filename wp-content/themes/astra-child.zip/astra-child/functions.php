<?php
include('includes/state-shortcodes.php');
add_action( 'wp_enqueue_scripts', 'astra_child_enqueue_styles' );
function astra_child_enqueue_styles() {
	$parenthandle = 'parent-style';
	$theme        = wp_get_theme();
	wp_enqueue_style( $parenthandle,
		get_template_directory_uri() . '/style.css',
		array(),
		$theme->parent()->get( 'Version' )
	);
	wp_enqueue_style( 'child-style',
		get_stylesheet_uri(),
		array( $parenthandle ),
		$theme->get( 'Version' )
	);
}

function create_posttype() {
	register_post_type( 'states',
	// CPT Options
		array(
		  'labels' => array(
		   'name' => __( 'States' ),
		   'singular_name' => __( 'States' )
		  ),
		  'public' => true,
		  'has_archive' => false,
		  'rewrite' => array('slug' => 'states'),
		)
	);
}

add_action( 'init', 'create_posttype' );
